

import UIKit

class Cell : UICollectionViewCell {
    @IBOutlet var lab : UILabel!
    @IBOutlet var container : UIView!
}
