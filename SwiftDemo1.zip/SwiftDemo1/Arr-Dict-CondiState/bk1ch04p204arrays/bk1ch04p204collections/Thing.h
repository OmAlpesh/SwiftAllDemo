

#import <Foundation/Foundation.h>

@interface Pep : NSObject

- (nonnull NSArray*) boys;
- (nonnull NSArray<NSString*>*) boysGood;

@end
