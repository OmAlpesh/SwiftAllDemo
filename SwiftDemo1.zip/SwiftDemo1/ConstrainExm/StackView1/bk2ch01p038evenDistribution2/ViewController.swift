
import UIKit

class ViewController: UIViewController {

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("here") // put breakpoint here so we can pause and examine layout
    }

}

